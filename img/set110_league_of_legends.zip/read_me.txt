This League Of Legends Cursor Set was created by Cyberdyne12489

http://cyberdyne12489.deviantart.com/

Downloaded from with instructions by www.cursors-4u.com/

================================================================================
================================================================================
Right Click the League Of Legends .inf and choose "install"
Go to Control Panel
Click On Mouse Settings
Click on the pointers tab
Under Scheme Choose "League Of Legends"
Click Apply.

http://www.cursors-4u.com/2011/11/04/how-to-install-cursors-on-windows-7-or-vista.html